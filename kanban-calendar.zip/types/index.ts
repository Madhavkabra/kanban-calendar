export interface Event {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  time: string;
}
